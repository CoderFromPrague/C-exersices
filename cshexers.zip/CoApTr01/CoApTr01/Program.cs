﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoApTr01
{
    class Program
    {
        static void Main(string[] args)
        {
            /* add arguments from CMD */
            //int val = int.Parse(args[0]);
            //int val1 = int.Parse(args[1]);
            //Console.WriteLine("Num: " + val);

            /* read value with Parse and convert to binary*/
            //int value;

            //Console.Write("\nNumber : ");
            //value = int.Parse(Console.ReadLine());
            //Console.Write("Binary String: " + Convert.ToString(value, 2));
            //Console.ReadLine();

            ///* read bool value and convert to int */
            //Console.Write("\nInput : ");
            //var x = Convert.ToBoolean(Console.ReadLine());
            //Console.Write("\nOutput bool : {0}", Convert.ToInt16(x));
            //Console.ReadLine();

            /* Reading user input */
            int num1, num2, temp;
            Console.Write("\nEnter the First Number : ");
            num1 = int.Parse(Console.ReadLine());
            Console.Write("\nEnter the Second Number : ");
            num2 = int.Parse(Console.ReadLine());
            temp = num1;
            num1 = num2;
            num2 = temp;
            Console.Write("\nAfter Swapping : ");
            Console.Write("\nFirst Number : " + num1);
            Console.Write("\nSecond Number : " + num2);
            Console.ReadLine();

            /* Very simple boolean prompt */
            //        bool answer = false;
            //        Console.WriteLine("Is God willing to prevent evil? [Y/N]: ");
            //        try
            //        {
            //            answer = Console.ReadLine().ToBool();
            //            Console.WriteLine(answer);
            //        }
            //        catch (Exception)
            //        {
            //            Console.WriteLine("Invalid input");
            //        }
            //        Console.ReadLine();
            //    }
            //}
            //static class Extensions
            //{
            //    public static bool ToBool(this string input)
            //    {
            //        if (input.Equals("y", StringComparison.OrdinalIgnoreCase))
            //        {
            //            return true;
            //        }
            //        else if (input.Equals("n", StringComparison.OrdinalIgnoreCase))
            //        {
            //            return false;
            //        }
            //        else
            //        {
            //            throw new Exception("The data is not in the correct format.");
            //        }
            //    }

            /*  */
            //Console.WriteLine("... Press escape, a, then control X");
            //// Call ReadKey method and store result in local variable.
            //// ... Then test the result for escape.
            //ConsoleKeyInfo info = Console.ReadKey();
            //if (info.Key == ConsoleKey.Escape)
            //{
            //    Console.WriteLine("You pressed escape!");
            //}
            //// Call ReadKey again and test for the letter a.
            //info = Console.ReadKey();
            //if (info.KeyChar == 'a')
            //{
            //    Console.WriteLine("You pressed a");
            //}
            //// Call ReadKey again and test for control-X.
            //// ... This implements a shortcut sequence.
            //info = Console.ReadKey();
            //if (info.Key == ConsoleKey.X &&
            //info.Modifiers == ConsoleModifiers.Control)
            //{
            //    Console.WriteLine("You pressed control X");
            //}
            //Console.Read();

            /* Use unspecified key for ReadKey() */
            //int c = 0;
            //Console.WriteLine("The series is:");
            //for (int i = 1; i < 10; i++)
            //{
            //    c = c + i;
            //    Console.Write(c + " ");
            //}
            //Console.WriteLine("\npress any key to exit the process...");
            //// basic use of "Console.ReadKey()" method 
            //Console.ReadKey();

            /* Use specified key for ReadKey() */
            //int c = 0;
            //Console.WriteLine("The series is:");
            //for (int i = 1; i < 10; i++)
            //{
            //    c = c + i;
            //    Console.Write(c + " ");
            //}
            //Console.Write("\nPress 'Enter' to exit the process...");
            //while (Console.ReadKey().Key != ConsoleKey.Enter)
            //{
            //}

            /* after input number TryParse parses it and ends */
            //int op = 0;
            //string inss = string.Empty;
            //do
            //{
            //    Console.WriteLine("enter choice");
            //    inss = Console.ReadLine();
            //} while (!int.TryParse(inss, out op));

            /* write int number n int range and exit with Y/N */
            //int numVal = -1;
            //bool repeat = true;
            //while (repeat)
            //{
            //    Console.Write("Enter a number between −2,147,483,648 and +2,147,483,647 (inclusive): ");
            //    string input = Console.ReadLine();
            //    // ToInt32 can throw FormatException or OverflowException.
            //    try
            //    {
            //        numVal = Convert.ToInt32(input);
            //        if (numVal < Int32.MaxValue)
            //        {
            //            Console.WriteLine("The new value is {0}", ++numVal);
            //        }
            //        else
            //        {
            //            Console.WriteLine("numVal cannot be incremented beyond its current value");
            //        }
            //    }
            //    catch (FormatException)
            //    {
            //        Console.WriteLine("Input string is not a sequence of digits.");
            //    }
            //    catch (OverflowException)
            //    {
            //        Console.WriteLine("The number cannot fit in an Int32.");
            //    }
            //    Console.Write("Go again? Y/N: ");
            //    string go = Console.ReadLine();
            //    if (go.ToUpper() != "Y")
            //    {
            //        repeat = false;
            //    }
            //}

            /* some exes */
            //string s = "dsf";
            //string d = "dsf";
            //Console.WriteLine(s.Equals(d));
            //Console.WriteLine(s==d);
            //Console.WriteLine(d.GetType());
            //Console.ReadLine();
        }
    }
}
