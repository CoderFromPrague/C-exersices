﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConAp02
{
    class Program
    {
        static void Main(string[] args)
        {
            //string greeting = "      Hello World!       ";
            //Console.WriteLine($"[{greeting}]");

            //string trimmedGreeting = greeting.TrimStart();
            //Console.WriteLine($"[{trimmedGreeting}]");

            //trimmedGreeting = greeting.TrimEnd();
            //Console.WriteLine($"[{trimmedGreeting}]");

            //trimmedGreeting = greeting.Trim();
            //Console.WriteLine($"[{trimmedGreeting}]");

            //trimmedGreeting = trimmedGreeting.Replace("World!", "Friends!");
            //Console.WriteLine(trimmedGreeting);

            //Console.WriteLine(trimmedGreeting.ToUpper());
            //Console.WriteLine(trimmedGreeting.ToLower());

            //Console.WriteLine(trimmedGreeting.Contains("Hello").ToString());

            //string songLyrics = "You say goodbye, and I say hello";
            //Console.WriteLine(songLyrics.StartsWith("You"));
            //Console.WriteLine(songLyrics.StartsWith("goodbye"));

            //Console.WriteLine(songLyrics.EndsWith("hello"));
            //Console.WriteLine(songLyrics.EndsWith("goodbye"));
            //Console.ReadLine();

            //int max = int.MaxValue;
            //int min = int.MinValue;
            //Console.WriteLine($"The range of integers is {min} to {max}");
            //Console.ReadLine();

            //decimal min = decimal.MinValue;
            //decimal max = decimal.MaxValue;
            //Console.WriteLine($"The range of the decimal type is {min} to {max}");
            //Console.ReadLine();

            //double radius = 2.50;
            //double area = Math.PI * radius * radius;
            //Console.WriteLine(area); Console.ReadLine();

            //Console.WriteLine(Fact(15));
            //Console.ReadLine();

            /* List<T> */
            //do
            //{
            //    var names = new List<string> { "<name>", "Ana", "Felipe" };
            //    foreach (var name in names)
            //    {
            //        Console.WriteLine($"Hello {name.ToUpper()}!");
            //    }
            //    Console.WriteLine();
            //    names.Add("Maria");
            //    names.Add("Bill");
            //    names.Remove("Ana");
            //    foreach (var name in names)
            //    {
            //        Console.WriteLine($"Hello {name.ToUpper()}!");
            //    }
            //    Console.WriteLine($"My name is {names[0]}.");
            //    Console.WriteLine($"I've added {names[2]} and {names[3]} to the list.");
            //    Console.WriteLine($"The list has {names.Count} people in it");


            //    var index = names.IndexOf("Felipe");
            //    if (index != -1)
            //        Console.WriteLine($"The name {names[index]} is at index {index}");

            //    var notFound = names.IndexOf("Not Found");
            //    Console.WriteLine($"When an item is not found, IndexOf returns {notFound}");

            //    names.Sort();
            //    foreach (var name in names)
            //    {
            //        Console.WriteLine($"Hello {name.ToUpper()}!");
            //    }

            //} while (Console.ReadKey().Key != ConsoleKey.E);


            /* Print Fibonacchi numbers */
            //var fibonacciNumbers = new List<int> { 1, 1 };
            //while (fibonacciNumbers.Count < 20)
            //{
            //    var previous = fibonacciNumbers[fibonacciNumbers.Count - 1];
            //    var previous2 = fibonacciNumbers[fibonacciNumbers.Count - 2];

            //    fibonacciNumbers.Add(previous + previous2);
            //}
            //foreach (var item in fibonacciNumbers)
            //Console.WriteLine(item);

            //Console.ReadKey();


            /* COOL remove redundant numbers from list */
            //var numbers = new List<int> { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            //// Remove odd numbers.
            //for (var index = numbers.Count - 1; index >= 0; index--)
            //{
            //    if (numbers[index] % 2 == 1)
            //    {
            //        // Remove the element by specifying
            //        // the zero-based index in the list.
            //        numbers.RemoveAt(index);
            //    }
            //}
            //// Iterate through the list.
            //// A lambda expression is placed in the ForEach method
            //// of the List(T) object.
            //numbers.ForEach(
            //    number => Console.Write(number + " "));
            //// Output: 0 2 4 6 8
            //Console.ReadKey();

        }


        //static int Fact(int num)
        //{
        //    if (num == 1)
        //    {
        //        return 1;
        //    }
        //    return num * Fact(num - 1);
        //}
    }
}


